package com.sample.rm;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import com.filenet.api.core.Connection;
import com.filenet.api.core.Factory;
import com.filenet.api.util.UserContext;
import com.ibm.jarm.api.constants.DomainType;
import com.ibm.jarm.api.constants.RMClassName;
import com.ibm.jarm.api.constants.RMPropertyName;
import com.ibm.jarm.api.core.ContentRepository;
import com.ibm.jarm.api.core.DomainConnection;
import com.ibm.jarm.api.core.FilePlan;
import com.ibm.jarm.api.core.FilePlanRepository;
import com.ibm.jarm.api.core.RMDomain;
import com.ibm.jarm.api.core.RMFactory;
import com.ibm.jarm.api.core.RecordCategory;
import com.ibm.jarm.api.property.RMProperties;
import com.ibm.jarm.api.property.RMPropertyFilter;
import com.ibm.jarm.api.security.RMUser;

public class JARMSample {
	
	public static void main(String args[])
	{
		JARMSample sample = new JARMSample();
		
		RMDomain jarmDomain = sample.getDomain();
		FilePlanRepository filePlanRepo = sample.getRepository(jarmDomain);
		//String path = "/Records Management/File Plan";
		String path = "/Records Management/Dental File Plan/ERK+8Years/UCS";
		//RecordCategory recordCat = sample.getRecordCategory(path, filePlanRepo);
		
		RecordCategory recordCategory = sample.getRecordCategory(path, filePlanRepo);
		
		sample.createRecordCategoryWithCalendar(recordCategory);
		
	}
		
	
	public RecordCategory getRecordCategory(String path, FilePlanRepository filePlanRepo)
	{
		
		//FilePlan filePlan =
		//RMFactory.FilePlan.fetchInstance(filePlanRepo, path,
		//RMPropertyFilter.MinimumPropertySet);
		//System.out.printf("GUID for a file plan '%s' is %s.%n",
		//filePlan.getPathName(), filePlan.getObjectIdentity());
		
		RecordCategory recordCategory = RMFactory.RecordCategory.fetchInstance(filePlanRepo,path ,null);
		
		
		System.out.println(recordCategory.getName());
		
		return recordCategory;
		
		
	}
	
	public void createRecordCategoryWithCalendar(RecordCategory parent)
	{
		Calendar calendar = Calendar.getInstance();
		
		//calendar.getTime().y
		String year = new SimpleDateFormat("MMM").format(calendar.getTime());
		RMProperties jarmProps = RMFactory.RMProperties.createInstance(DomainType.P8_CE);
		jarmProps.putStringValue(RMPropertyName.RecordCategoryName, year);
		jarmProps.putStringValue(RMPropertyName.RecordCategoryIdentifier, year);
		//jarmProps.putStringValue(RMPropertyName.Reviewer, "jSmith");
		RecordCategory newRC = parent.addRecordCategory(RMClassName.RecordCategory, jarmProps, null);
		System.out.printf("Created new record category %s.%n", newRC.getRecordCategoryName());
		
	}
	public FilePlanRepository getRepository(RMDomain jarmDomain)
	{
		
		// ---- Retrieve a specific file plan repository by its symbolic name ----
		String fpReposSymbolicName = "FPOS";
		RMPropertyFilter filter = null; // Being lazy - request all properties.
		FilePlanRepository fpRepos =
		RMFactory.FilePlanRepository.fetchInstance(jarmDomain, fpReposSymbolicName, filter);
		System.out.printf("Single FPRepository DisplayName: %s, Id: %s%n",
		fpRepos.getDisplayName(), fpRepos.getObjectIdentity());
		
		return fpRepos;
		
	}
	
	
	

	public RMDomain getDomain() {

		boolean establishedSubject = false;

		RMDomain jarmDomain = null;
		
		try {
			// Example WSI transport URL for a FileNet P8 domain.
			String domainURL = "http://192.168.101.128:9080/wsi/FNCEWS40MTOM";
			String username = "p8admin";
			String password = "filenet";
			// ---- Connect and Authenticate using JACE ----
			// Acquire a JACE domain connection
			Connection jaceConnection = Factory.Connection.getConnection(domainURL);
			// Authenticate using JACE UserContext class.
			// The following JAAS stanza name can optionally be left
			// null to allow JACE to dynamically determine the correct
			// value based upon the URL format.
			String jaasStanza = "FileNetP8WSI";
			javax.security.auth.Subject jaasSubject = UserContext.createSubject(jaceConnection, username, password,
					jaasStanza);
			// Acquire JACE UserContext for the current thread.
			UserContext jaceUC = UserContext.get();
			jaceUC.pushSubject(jaasSubject);
			establishedSubject = true;
			// ---- (Optionally) Define user context locale ----
			jaceUC.setLocale(java.util.Locale.US);
			// ---- Perform custom application work ----
			// ...
			// ---- Acquire the JARM RMDomain ----     
			
			DomainConnection jarmConnection = com.ibm.jarm.api.util.P8CE_Convert.fromP8CE(jaceConnection);
			
			
			String domainIdent = null;  // For P8, null indicates 'local' domain.     
			RMPropertyFilter filter = RMPropertyFilter.MinimumPropertySet;     
			jarmDomain =        RMFactory.RMDomain.fetchInstance(jarmConnection, domainIdent, filter);     
			// Use this domain object to verify the current JAAS     //  Subject credentials.    
			RMUser jarmCurrentUser = jarmDomain.fetchCurrentUser();    
			System.out.printf("Domain name: %s, current user: %s%n",          
			jarmDomain.getName(), jarmCurrentUser.getDisplayName()); 
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		/*finally {
			if (establishedSubject) {
				// Un-establish the Subject from the current thread.
				UserContext.get().popSubject();
			}
		}*/
		
		return jarmDomain;
	}
	

}
